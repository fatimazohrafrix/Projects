package ma.education.tp1.introduction1;

import ma.education.tp1.introduction.Salle;

public class AccesHorsPackage extends Salle {

	public static void main(String[] args) {
		
		Salle SalleB = new Salle(3, "Salle B");
		System.out.println(SalleB.id);
		System.out.println(SalleB.nom);
	}
		
		public void afficher(Salle s) {
			System.out.println(s.id );
			System.out.println(s.nom );
			System.out.println(id );
			System.out.println(nom );

	}

}
