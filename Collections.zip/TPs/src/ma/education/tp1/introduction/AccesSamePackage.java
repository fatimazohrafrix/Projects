package ma.education.tp1.introduction;

public class AccesSamePackage {

	public static void main(String[] args) {
		
		Salle SalleA = new Salle(1, "Salle A");
		
		System.out.println(SalleA.id); 
		System.out.println(SalleA.nom);

	}

}
