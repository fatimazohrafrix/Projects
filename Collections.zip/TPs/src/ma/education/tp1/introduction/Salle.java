package ma.education.tp1.introduction;

public class Salle {
	
	 public long id;
	 public String nom;
	
	//cons sans para
	 public Salle () {}
	// cons avec le para id
	public Salle(String nom) {
		this.nom = nom;
	}
	// cons avec deux para id et nom
	public Salle(long id, String nom) {
		this(nom);
		this.id=id;
		
	}
	
	

}
