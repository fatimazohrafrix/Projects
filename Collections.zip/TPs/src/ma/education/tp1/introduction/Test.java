package ma.education.tp1.introduction;

public class Test {

	public static void main(String[] args) {
		
		Salle e1 = new Salle();
		Salle e2 = new Salle ("Salle informatique");
		Salle e3 = new Salle (2,"Salle des cours");
		
		System.out.println("e2 nom: " + e2.nom);
		System.out.println("e3 id: " +  e3.id  +  "e3 nom" +  e3.nom);

	}

}
