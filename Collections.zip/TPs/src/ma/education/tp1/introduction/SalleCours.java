package ma.education.tp1.introduction;

public class SalleCours extends Salle{
	
	int NbrPlace;
	
	public SalleCours(long id, String nom, int NbrPlace) {
		
		super(id, nom);
		this.NbrPlace = NbrPlace;	
	}

}
