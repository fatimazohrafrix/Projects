package ma.education.tp4.singleton;

public class Terre {
	double distanceTosoleil;
	double surface;
	
	private static Terre()


}
