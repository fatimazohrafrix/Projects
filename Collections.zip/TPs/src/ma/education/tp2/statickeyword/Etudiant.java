package ma.education.tp2.statickeyword;

public class Etudiant {
	
	//public long id;
	//public String nom;
	//static public int nbEtudiants;
	
	//public Etudiant (long id, String nom,int nb) {
		//this.id = id;
	//	this.nom = nom;
	//	nbEtudiants = nb;
	//}
	static String cat;
	int age;
	Etudiant(int age, String c){
		this.age=age;
		cat+= c;
		
	}



}



