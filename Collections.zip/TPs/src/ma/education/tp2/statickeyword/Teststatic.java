package ma.education.tp2.statickeyword;

public class Teststatic {
	public static void main(String[] args) {

	
		// TODO Auto-generated constructor stub
		
			
		Etudiant e1=new Etudiant(20, "a");
			
				
				Etudiant e2=new Etudiant(10, "b");
				System.out.println(Etudiant.cat);
			}

	}

	//private static void Teststatic() {
		// TODO Auto-generated method stub
		
	//}
	//	Etudiant e1= new Etudiant(1, "AHMED", 30);
		//Etudiant e2= new Etudiant(2, "SAID", 20);

	//	System.out.println("e1 id"+ e1.id + "e1 nom" + e1.nom + "e1 nbEtudiants" + e1.nbEtudiants);
//		System.out.println("e2 id"+ e2.id + "e2 nom" + e2.nom + "e2 nbEtudiants" + e2.nbEtudiants);
	

	//private static void Teststatic() {
		// TODO Auto-generated method stub
		
	



